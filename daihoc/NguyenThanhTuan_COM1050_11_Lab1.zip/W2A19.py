Week = ['Monday',  
'Tuesday',
'Wednesday', 
'Thursday',
'Friday', 
'Saturday', 
'Sunday']
print('\n'.join(Week))