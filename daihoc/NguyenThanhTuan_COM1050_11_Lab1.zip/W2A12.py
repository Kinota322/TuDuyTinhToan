length = int(input())
print((length ** 2) * 6)