a1, b1, c1, a2, b2, a3 = map(float, input().split())
print("{res:.1f}".format(res = ((a1 + b1 + c1) + (a2 + b2) * 2 + a3 * 3) / 10))