def star_nunmber(n):
    return 6 * n * (n - 1) + 1

n = int(input())

print(star_nunmber(n))