a = int(input())
b = int(input())

tong = a + b
hieu = a - b
tich = a * b
phan_nguyen = a // b
phan_du = a % b
chia_thuc = a / b

print(tong)
print(hieu)
print(tich)
print(phan_nguyen)
print(phan_du)
print(f"{chia_thuc:.2f}")