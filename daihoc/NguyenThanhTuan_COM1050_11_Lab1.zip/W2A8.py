Celcius = float(input())
print("{Fahrenheit:.2f}".format(Fahrenheit = (9 / 5) * Celcius + 32))