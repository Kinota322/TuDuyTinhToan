letter = ord(input().split()[0])
print(letter, chr(letter + ord('A') - ord('a')))