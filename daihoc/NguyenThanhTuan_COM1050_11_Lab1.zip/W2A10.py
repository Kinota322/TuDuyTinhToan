name1, name2, name3 = input().split()
print('Hi {a}, {b} and {c}'.format(a = name3, b = name2, c = name1))