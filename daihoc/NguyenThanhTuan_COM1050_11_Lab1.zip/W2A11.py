hours, mins = map(int, input().split())
print(hours * 60 * 60 + mins * 60)