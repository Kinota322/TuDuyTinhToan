x = float(input())

total = (x + 10) * 1.30 * 1.10

print(f"{total:.2f}")
