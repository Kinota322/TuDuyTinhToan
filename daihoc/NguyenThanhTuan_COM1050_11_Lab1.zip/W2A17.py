print("*    ")
print("***  ")
print("*****")