name = input()
print("Hello, " + name)